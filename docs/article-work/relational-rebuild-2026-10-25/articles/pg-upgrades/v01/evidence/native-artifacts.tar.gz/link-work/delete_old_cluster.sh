#!/bin/sh

rm -rf '/tmp/sc-pg-upgrades-20261025/run/link-old'
